export const environment = {
    production: false,
    apiUrl: 'http://localhost:3002' // Ejemplo de URL de tu API local
};
