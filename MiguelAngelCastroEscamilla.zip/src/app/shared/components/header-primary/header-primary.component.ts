import { Component } from '@angular/core';

@Component({
  selector: 'header-primary',
  imports: [],
  templateUrl: './header-primary.component.html',
  styleUrl: './header-primary.component.scss'
})
export class HeaderPrimaryComponent {

}
